# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 10:56:48 2019

@author: LPollen
"""

Prospecting = {
        
bfa : {

osmenite : {
"quantity" : 16760,

gems : {
"Leviathan's Eye" : [515, ], # Num returned, itemID       
"Azsharine" : [179, ],
"Sage Agate" : [181, ],
"Sand Spinel" : [738, ] ,
"Sea Currant" : [757, ] ,
"Lava Lazuli" : [715, ] ,
"Dark Opal" : [782, ] ,
#"" : [,] ,
}        

}
       
}
        
}